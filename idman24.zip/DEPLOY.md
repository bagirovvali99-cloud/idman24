# İdman24 — İnternetə yerləşdirmə (Render, pulsuz)

Bu addımlardan sonra saytın real linki olacaq (məs. `https://idman24.onrender.com`)
və proxy/VPN problemi olmayacaq. Hamısı pulsuzdur.

Lazım olan fayllar (hamısı bir qovluqda olsun):
`idman24_server.py`, `requirements.txt`, `render.yaml`, `Procfile`

---

## Addım 1 — GitHub-da repo yarat
1. https://github.com → daxil ol (hesab yoxdursa, pulsuz aç).
2. Sağ üst **+** → **New repository**.
3. Ad: `idman24` → **Create repository**.
4. Açılan səhifədə **"uploading an existing file"** linkinə bas.
5. Yuxarıdakı 4 faylı sürükləyib burax → **Commit changes**.

## Addım 2 — Render-də yerləşdir
1. https://render.com → **Get Started** (GitHub ilə daxil ol — ən asanı).
2. **New +** → **Web Service**.
3. `idman24` reposunu seç → **Connect**.
4. Render `render.yaml`-ı avtomatik tanıyacaq. Tanımasa:
   - **Language/Runtime:** Python 3
   - **Build Command:** boş burax (və ya `echo ok`)
   - **Start Command:** `python idman24_server.py`
   - **Instance Type:** Free
5. **Create Web Service** → 1-2 dəqiqə gözlə.

## Addım 3 — Hazırdır
- Render yuxarıda linki göstərəcək: `https://idman24-xxxx.onrender.com`
- Bu linki kimə istəsən paylaşa bilərsən.
- Admin paneli: linkin sonuna heç nə əlavə etmə — sağ yuxarıdakı **“+ Xəbər əlavə et”** düyməsi.
  Parol: `idman2026` (Render-də **Environment → IDMAN24_ADMIN** ilə dəyişə bilərsən).

---

### Qeydlər
- **Pulsuz plan** 15 dəqiqə istifadəsizlikdən sonra “yuxuya” gedir; növbəti açılışda
  ilk yüklənmə 30-50 saniyə çəkə bilər. Sonra normal işləyir.
- Öz əlavə etdiyin xəbərlər serverdə fayla yazılır; yenidən deploy etdikdə sıfırlana bilər
  (daimi saxlama lazımdırsa, sonra verilənlər bazası əlavə edə bilərik).
- Öz domenini (məs. `idman24.az`) almısansa, Render-də **Settings → Custom Domain** ilə bağlaya bilərsən.
